            <div class="left side-menu" style="background-color: #2d2b7e;color:white;">
                <div class="sidebar-inner slimscrollleft">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <ul>
                            <li class="menu-title">Navigation</li>

                            <li class="has_sub">
                                <a href="dashboard.php" class="waves-effect"><i class="mdi mdi-view-dashboard"></i>
                                    <span> Dashboard </span> </a>

                            </li>
                                

                            <!--Add USER-->
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i
                                        class="mdi mdi-format-list-bulleted"></i> <span> USER </span> <span
                                        class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="add-user.php"> Add user </a></li>
                                    <li><a href="manage-user.php"> Manage user</a></li>
                                </ul>
                            </li>

                             <!--Add USER-->
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i
                                        class="mdi mdi-format-list-bulleted"></i> <span> STUDENT </span> <span
                                        class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="manage-primary-student.php"> Student</a></li>
                                </ul>
                            </li>

                            <!--Add USER-->
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i
                                        class="mdi mdi-format-list-bulleted"></i> <span> STAFF </span> <span
                                        class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="manage-staff.php"> Staff</a></li>
                                </ul>
                            </li>

                        </ul>
                    </div>
                    <!-- Sidebar -->
                    <div class="clearfix"></div>

                    <div class="help-box">
                        <h5 class="text-muted m-t-0">For Help ?</h5>
                        <p style="font-size:10px;" class=""><span class="text-custom">Email:</span> <br />
                            ndagijimanaenock11@gmail.com</p>
                    </div>

                </div>
                <!-- Sidebar -left -->

            </div>